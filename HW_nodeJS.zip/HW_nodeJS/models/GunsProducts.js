const Sequelize = require('sequelize');
const MySql = require('../libs/MySql')

class Products extends Sequelize.Model {
  static async connect () {
    let connected = false;
    let sequelize = await MySql.Open();
    Products.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      brand: Sequelize.STRING,
      type: Sequelize.STRING,
      barreled: Sequelize.INTEGER
    }, {
      sequelize,
      modelName: 'Guns'
    });
    connected = true;
    return connected;
  }

  static async close() {
    let status = await MySql.Close();
    return status
  }
}

module.exports = Products