const Server = require('./middlewares/Server')
const GunsRouter = require('./routers/GunsRouter')
var server = new Server();
server.use(GunsRouter);